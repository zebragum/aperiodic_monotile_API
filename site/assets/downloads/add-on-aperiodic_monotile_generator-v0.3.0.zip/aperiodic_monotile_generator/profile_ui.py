"""Side profile editor — normalized edge profiles (aspartate/spectre model)."""

from __future__ import annotations

import math

import bpy
from bpy.props import BoolProperty, CollectionProperty, FloatProperty, IntProperty
from bpy.types import Operator, PropertyGroup

_PROFILE_BOX_W = 220
_PROFILE_BOX_H = 130
_PROFILE_PAD = 12

# Canonical Tile(1,1) ring (same as API) — kept local so Blender does not need spectre_patch.
_SQRT3 = math.sqrt(3.0)
_PROTOTILE_RING = [
    (0.0, 0.0),
    (1.0, 0.0),
    (1.5, -_SQRT3 / 2.0),
    (1.5 + _SQRT3 / 2.0, 0.5 - _SQRT3 / 2.0),
    (1.5 + _SQRT3 / 2.0, 1.5 - _SQRT3 / 2.0),
    (2.5 + _SQRT3 / 2.0, 1.5 - _SQRT3 / 2.0),
    (3.0 + _SQRT3 / 2.0, 1.5),
    (3.0, 2.0),
    (3.0 - _SQRT3 / 2.0, 1.5),
    (2.5 - _SQRT3 / 2.0, 1.5 + _SQRT3 / 2.0),
    (1.5 - _SQRT3 / 2.0, 1.5 + _SQRT3 / 2.0),
    (0.5 - _SQRT3 / 2.0, 1.5 + _SQRT3 / 2.0),
    (-_SQRT3 / 2.0, 1.5),
    (0.0, 1.0),
]


def _rotate_about(px: float, py: float, angle: float, ox: float, oy: float) -> tuple[float, float]:
  c, s = math.cos(angle), math.sin(angle)
  dx, dy = px - ox, py - oy
  return ox + c * dx - s * dy, oy + s * dx + c * dy


def _inverse_profile(profile: list[tuple[float, float]]) -> list[tuple[float, float]]:
  out: list[tuple[float, float]] = []
  for x, y in reversed(profile):
      rx, ry = _rotate_about(x, y, math.pi, 0.5, 0.0)
      out.append((rx, ry))
  return out


def decorate_ring_with_profile(
    ring: list[tuple[float, float]],
    profile: list[tuple[float, float]],
    *,
    amplitude: float = 1.0,
    alternate_edges: bool = True,
) -> list[tuple[float, float]]:
  """Replace each edge with a scaled profile (see aspartate/spectre)."""

  if len(profile) < 2:
      return list(ring)

  amp = float(amplitude)
  scaled = [(x, y * amp) for x, y in profile]
  inverse = _inverse_profile(scaled) if alternate_edges else scaled
  out: list[tuple[float, float]] = []
  chirality = 1

  for i in range(len(ring)):
      x0, y0 = ring[i]
      x1, y1 = ring[(i + 1) % len(ring)]
      dx, dy = x1 - x0, y1 - y0
      elen = math.hypot(dx, dy)
      if elen < 1e-12:
          continue
      angle = math.atan2(dy, dx)
      edge_profile = scaled if chirality == 1 else inverse

      for j, (px, py) in enumerate(edge_profile):
          lx, ly = px * elen, py * elen
          wx, wy = _rotate_about(lx, ly, angle, 0.0, 0.0)
          wx += x0
          wy += y0
          if j == 0 and out:
              continue
          out.append((wx, wy))

      if alternate_edges:
          chirality *= -1

  return out if out else list(ring)


class MonotileProfilePoint(PropertyGroup):
  x: FloatProperty(name="Along edge", min=0.0, max=1.0, default=0.5)
  offset_y: FloatProperty(
      name="Bulge",
      min=-0.75,
      max=0.75,
      default=0.0,
      description="Perpendicular offset as a fraction of edge length",
  )


def _profile_points_sorted(settings) -> list[tuple[float, float]]:
  pts: list[tuple[float, float]] = [(0.0, 0.0)]
  for item in sorted(settings.profile_points, key=lambda p: p.x):
      pts.append((float(item.x), float(item.offset_y)))
  pts.append((1.0, 0.0))
  return pts


def profile_points_for_api(settings) -> list[list[float]]:
  return [[float(x), float(y)] for x, y in _profile_points_sorted(settings)]


def _set_profile_points(settings, points: list[tuple[float, float]]) -> None:
  settings.profile_points.clear()
  for x, y in points:
      if abs(x) < 1e-6 or abs(x - 1.0) < 1e-6:
          continue
      item = settings.profile_points.add()
      item.x = x
      item.offset_y = y


def _norm_to_screen(
    x: float,
    y: float,
    box_x: int,
    box_y: int,
    box_w: int,
    box_h: int,
    depth: float,
) -> tuple[float, float]:
  """Map profile coords to screen pixels inside the editor box."""

  inner_w = box_w - 2 * _PROFILE_PAD
  inner_h = box_h - 2 * _PROFILE_PAD
  sx = box_x + _PROFILE_PAD + x * inner_w
  sy = box_y + _PROFILE_PAD + inner_h * 0.5 - (y / max(depth, 0.05)) * (inner_h * 0.42)
  return sx, sy


def _screen_to_norm(
    sx: float,
    sy: float,
    box_x: int,
    box_y: int,
    box_w: int,
    box_h: int,
    depth: float,
) -> tuple[float, float]:
  inner_w = box_w - 2 * _PROFILE_PAD
  inner_h = box_h - 2 * _PROFILE_PAD
  x = (sx - box_x - _PROFILE_PAD) / max(inner_w, 1.0)
  y = ((box_y + _PROFILE_PAD + inner_h * 0.5 - sy) / (inner_h * 0.42)) * max(depth, 0.05)
  return max(0.0, min(1.0, x)), max(-0.75, min(0.75, y))


def _find_shared_monotile_mesh():
  for mesh in bpy.data.meshes:
      if mesh.name.startswith("Monotile Tile "):
          return mesh
  return None


def _rebuild_mesh_from_ring(mesh: bpy.types.Mesh, ring_xy: list) -> None:
  verts = [(float(x), float(y), 0.0) for x, y in ring_xy]
  face = [tuple(range(len(verts)))]
  mesh.clear_geometry()
  mesh.from_pydata(verts, [], face)
  mesh.update()
  mesh.validate()


def apply_profile_to_imported_tiles(settings) -> tuple[int, str | None]:
  """Rebuild the shared prototile mesh from the current profile (local, no API)."""

  profile = profile_points_for_api(settings)
  ring = decorate_ring_with_profile(
      _PROTOTILE_RING,
      [(float(x), float(y)) for x, y in profile],
      amplitude=float(settings.profile_depth),
      alternate_edges=bool(settings.profile_symmetric),
  )

  mesh = _find_shared_monotile_mesh()
  if mesh is None:
      return 0, "Import a patch first (editable N-gon instances share one mesh)"

  _rebuild_mesh_from_ring(mesh, ring)
  users = sum(1 for obj in bpy.data.objects if obj.data == mesh)
  return users, None


class MONOTILE_UL_profile_points(bpy.types.UIList):
  def draw_item(self, context, layout, data, item, icon, active_data, active_propname, index):
      if self.layout_type in {"DEFAULT", "COMPACT"}:
          layout.prop(item, "x", text="")
          layout.prop(item, "offset_y", text="Bulge")


class MONOTILE_OT_profile_add_point(Operator):
  bl_idname = "monotile.profile_add_point"
  bl_label = "Add Profile Point"
  bl_options = {"REGISTER", "UNDO"}

  def execute(self, context):
      settings = context.scene.monotile_generator
      item = settings.profile_points.add()
      item.x = 0.5
      item.offset_y = 0.12
      settings.side_style = "custom"
      return {"FINISHED"}


class MONOTILE_OT_profile_remove_point(Operator):
  bl_idname = "monotile.profile_remove_point"
  bl_label = "Remove Profile Point"
  bl_options = {"REGISTER", "UNDO"}

  def execute(self, context):
      settings = context.scene.monotile_generator
      idx = settings.profile_points_index
      if 0 <= idx < len(settings.profile_points):
          settings.profile_points.remove(idx)
      settings.side_style = "custom"
      return {"FINISHED"}


class MONOTILE_OT_profile_reset(Operator):
  bl_idname = "monotile.profile_reset"
  bl_label = "Straight Edge"
  bl_options = {"REGISTER", "UNDO"}

  def execute(self, context):
      settings = context.scene.monotile_generator
      settings.profile_points.clear()
      settings.side_style = "flat"
      return {"FINISHED"}


class MONOTILE_OT_profile_preset_wiggly(Operator):
  bl_idname = "monotile.profile_preset_wiggly"
  bl_label = "Wiggly Preset"
  bl_options = {"REGISTER", "UNDO"}

  def execute(self, context):
      settings = context.scene.monotile_generator
      _set_profile_points(
          settings,
          [
              (0.2, 0.14),
              (0.4, -0.1),
              (0.6, 0.14),
              (0.8, -0.1),
          ],
      )
      settings.side_style = "custom"
      settings.profile_depth = 0.12
      return {"FINISHED"}


class MONOTILE_OT_apply_side_profile(Operator):
  bl_idname = "monotile.apply_side_profile"
  bl_label = "Apply Profile to Tiles"
  bl_description = (
      "Rebuild the shared N-gon mesh from the profile editor (all instances update). "
      "Does not call the API"
  )
  bl_options = {"REGISTER", "UNDO"}

  def execute(self, context):
      settings = context.scene.monotile_generator
      count, err = apply_profile_to_imported_tiles(settings)
      if err:
          self.report({"ERROR"}, err)
          return {"CANCELLED"}
      self.report({"INFO"}, f"Updated shared tile mesh used by {count} instance(s).")
      return {"FINISHED"}


class MONOTILE_OT_edit_side_profile(Operator):
  bl_idname = "monotile.edit_side_profile"
  bl_label = "Edit Side Profile"
  bl_description = "Drag control points on a normalized edge profile (LMB drag, RMB add, ESC done)"
  bl_options = {"REGISTER", "UNDO"}

  _handle = None
  _drag_index: int | None = None
  _box_x = 0
  _box_y = 0

  def _profile_screen_points(self, context) -> list[tuple[float, float]]:
      settings = context.scene.monotile_generator
      depth = float(settings.profile_depth)
      pts = _profile_points_sorted(settings)
      return [
          _norm_to_screen(x, y, self._box_x, self._box_y, _PROFILE_BOX_W, _PROFILE_BOX_H, depth)
          for x, y in pts
      ]

  def _pick_point(self, context, mx: float, my: float) -> int | None:
      screen_pts = self._profile_screen_points(context)
      best_i = None
      best_d = 18.0
      for i, (sx, sy) in enumerate(screen_pts):
          if i == 0 or i == len(screen_pts) - 1:
              continue
          d = ((mx - sx) ** 2 + (my - sy) ** 2) ** 0.5
          if d < best_d:
              best_d = d
              best_i = i - 1
      return best_i

  def _draw_callback(self, op, context):
      import blf
      import gpu
      from gpu_extras.batch import batch_for_shader

      settings = context.scene.monotile_generator
      depth = float(settings.profile_depth)
      bx, by = self._box_x, self._box_y
      bw, bh = _PROFILE_BOX_W, _PROFILE_BOX_H

      verts = [
          (bx, by),
          (bx + bw, by),
          (bx + bw, by + bh),
          (bx, by + bh),
      ]
      gpu.state.blend_set("ALPHA")
      shader = gpu.shader.from_builtin("UNIFORM_COLOR")
      batch = batch_for_shader(shader, "LINE_LOOP", {"pos": verts})
      shader.bind()
      shader.uniform_float("color", (0.15, 0.15, 0.18, 0.92))
      batch.draw(shader)

      inner_y = by + bh - _PROFILE_PAD
      base = [(bx + _PROFILE_PAD, inner_y), (bx + bw - _PROFILE_PAD, inner_y)]
      batch = batch_for_shader(shader, "LINES", {"pos": base})
      shader.uniform_float("color", (0.45, 0.45, 0.5, 1.0))
      batch.draw(shader)

      profile_pts = _profile_points_sorted(settings)
      screen_pts = [
          _norm_to_screen(x, y, bx, by, bw, bh, depth) for x, y in profile_pts
      ]
      if len(screen_pts) >= 2:
          batch = batch_for_shader(shader, "LINE_STRIP", {"pos": screen_pts})
          shader.uniform_float("color", (0.95, 0.35, 0.25, 1.0))
          batch.draw(shader)

      for i, (sx, sy) in enumerate(screen_pts):
          r = 5.0 if i == 0 or i == len(screen_pts) - 1 else 7.0
          color = (0.3, 0.55, 0.95, 1.0) if i == 0 or i == len(screen_pts) - 1 else (0.95, 0.35, 0.25, 1.0)
          circle = []
          for a in range(0, 360, 30):
              rad = a * 3.14159265 / 180.0
              circle.append((sx + r * math.cos(rad), sy + r * math.sin(rad)))
          batch = batch_for_shader(shader, "LINE_LOOP", {"pos": circle})
          shader.uniform_float("color", color)
          batch.draw(shader)

      blf.size(0, 11)
      blf.color(0, 1.0, 1.0, 1.0, 0.85)
      blf.position(0, bx + 6, by + bh - 16, 0)
      blf.draw(0, "Side profile (0,0)→(1,0)  ESC=done")

  def modal(self, context, event):
      settings = context.scene.monotile_generator
      depth = float(settings.profile_depth)

      if event.type in {"RIGHTMOUSE", "ESC"}:
          self.cancel(context)
          return {"CANCELLED"}

      if event.type == "LEFTMOUSE" and event.value == "PRESS":
          pick = self._pick_point(context, event.mouse_region_x, event.mouse_region_y)
          if pick is not None and 0 <= pick < len(settings.profile_points):
              self._drag_index = pick
          else:
              x, y = _screen_to_norm(
                  event.mouse_region_x,
                  event.mouse_region_y,
                  self._box_x,
                  self._box_y,
                  _PROFILE_BOX_W,
                  _PROFILE_BOX_H,
                  depth,
              )
              if 0.05 < x < 0.95:
                  item = settings.profile_points.add()
                  item.x = x
                  item.offset_y = y
                  settings.side_style = "custom"
                  self._drag_index = len(settings.profile_points) - 1

      if event.type == "LEFTMOUSE" and event.value == "RELEASE":
          self._drag_index = None

      if event.type == "MOUSEMOVE" and self._drag_index is not None:
          idx = self._drag_index
          if 0 <= idx < len(settings.profile_points):
              x, y = _screen_to_norm(
                  event.mouse_region_x,
                  event.mouse_region_y,
                  self._box_x,
                  self._box_y,
                  _PROFILE_BOX_W,
                  _PROFILE_BOX_H,
                  depth,
              )
              settings.profile_points[idx].x = max(0.02, min(0.98, x))
              settings.profile_points[idx].offset_y = y
              settings.side_style = "custom"

      if context.area:
          context.area.tag_redraw()
      return {"RUNNING_MODAL"}

  def invoke(self, context, event):
      region = context.region
      self._box_x = max(8, region.width - _PROFILE_BOX_W - 16)
      self._box_y = max(8, region.height - _PROFILE_BOX_H - 48)
      args = (self, context)
      self._handle = bpy.types.SpaceView3D.draw_handler_add(
          self._draw_callback, args, "WINDOW", "POST_PIXEL"
      )
      context.window_manager.modal_handler_add(self)
      return {"RUNNING_MODAL"}

  def cancel(self, context):
      if self._handle is not None:
          bpy.types.SpaceView3D.draw_handler_remove(self._handle, "WINDOW")
          self._handle = None
      if context.area:
          context.area.tag_redraw()


def draw_side_style_box(layout, context) -> None:
  settings = context.scene.monotile_generator
  box = layout.box()
  box.label(text="Side Style", icon="MOD_CURVE")
  box.prop(settings, "side_style", text="Style")
  if settings.side_style in {"curvy", "wavy", "jagged", "blocky"}:
      box.prop(settings, "side_style_amplitude", text="Amount")
      if settings.side_style == "wavy":
          box.prop(settings, "side_style_wavy_segments", text="Wavy Detail")
  if settings.side_style == "custom":
      box.prop(settings, "profile_depth", text="Depth")
      box.prop(settings, "profile_symmetric", text="Alternate edges")
      row = box.row()
      row.template_list(
          "MONOTILE_UL_profile_points",
          "",
          settings,
          "profile_points",
          settings,
          "profile_points_index",
          rows=3,
      )
      col = row.column(align=True)
      col.operator("monotile.profile_add_point", icon="ADD", text="")
      col.operator("monotile.profile_remove_point", icon="REMOVE", text="")
      row2 = box.row(align=True)
      row2.operator("monotile.profile_reset", text="Straight")
      row2.operator("monotile.profile_preset_wiggly", text="Wiggly")
      box.operator("monotile.edit_side_profile", icon="GREASEPENCIL")
      box.operator("monotile.apply_side_profile", icon="FILE_REFRESH")
      box.label(text="Edit profile then Apply, or Generate with Custom", icon="INFO")


PROFILE_CLASSES = (
  MonotileProfilePoint,
  MONOTILE_UL_profile_points,
  MONOTILE_OT_profile_add_point,
  MONOTILE_OT_profile_remove_point,
  MONOTILE_OT_profile_reset,
  MONOTILE_OT_profile_preset_wiggly,
  MONOTILE_OT_apply_side_profile,
  MONOTILE_OT_edit_side_profile,
)
